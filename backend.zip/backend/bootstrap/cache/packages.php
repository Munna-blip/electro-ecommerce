<?php return array (
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'theihasan/laravel-bkash' => 
  array (
    'aliases' => 
    array (
      'Bkash' => 'Ihasan\\Bkash\\Facades\\Bkash',
    ),
    'providers' => 
    array (
      0 => 'Ihasan\\Bkash\\BkashServiceProvider',
    ),
  ),
);